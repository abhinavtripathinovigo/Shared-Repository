# Reviewed delivery verification — v0.3

Date: 5 November 2026. Windows x64, workspace .NET SDK 10.0.403.

- Release build and test command succeeded: 33 passed, 0 failed, 0 skipped.
- Reviewed tests cover Draft completion, stable regular ID, separate child ID, fixed relative expiry and replay, configured duration, parent expiry cap, profile aliases/conflicts, target traversal and origin rejection, content validation, shared access counters, ownership and parent invalidation.
- HTTP integration test exercises CreateURL → UpdateURL → CreateTemporaryURL → GenerateQR, checks exactly seven temporary-response properties, opens the /t/ route, and receives PNG bytes.
- QR tests cover PNG decoding with and without an icon, SVG, custom pixel dimensions, kind mismatch and the too-small default PNG validation. Icon footprint was reduced to improve decoding reliability; final physical PDF sizes still require scanner testing.
- OpenAPI contains all 21 implemented controller operations, including legacy routes and reviewed v2. Swagger is served locally in Development.

Not executed: deployment to the user's Visual Studio installation, real gateway/ECM/identity integrations, production capacity or disaster-recovery testing, and business acceptance of the open design choices. SQLite and local protected storage remain a reference deployment, not a production high-availability design. Workbook acceptance scenarios remain marked Not run; the automated checks above are a separate engineering test record.

## Historical verification record

# Verification record

Date: 27 October 2026. Delivery: v0.2 controller/service/repository refactor. Platform: Windows x64. SDK: workspace-local .NET 10.0.403, downloaded from Microsoft's distribution and checked against its published SHA-512 hash.

## Completed

- Release compilation succeeded with zero compiler warnings and zero errors.
- **26 automated tests passed; zero failed; zero skipped.** Final test execution reported approximately 13 seconds, excluding build/startup time.
- Covered idempotency and concurrent creation, caller ownership, missing/stale ETags, fixed-expiry boundaries, renewal after expiry, target-path rejection, BaseUrl composition, target variants, invalid/immutable content updates, authentication policy enforcement, private session/evidence/cookie checks, concurrent attempt limits, durable store reopening, protected persisted payloads, revocation and QR rendering.
- QR PNGs with and without a registered icon were decoded using ZXing; both decoded to the exact original public URL. SVG output was checked for embedded approved image content and absence of script markup.
- HTTP tests covered anonymous management denial, unknown JSON field rejection, callback authorization, and a complete public Content journey including CSRF validation and exact returned PDF bytes.
- An additional HTTP test exercised the new temporary-creation, metadata, target/status update, QR and lifecycle controllers in one journey, checking expiry, ETags, PNG response and denied public access after revocation.
- Browser JavaScript syntax and PowerShell demonstration-script syntax checks passed.
- Release publish succeeded; the published output contains the access HTML page and browser JavaScript assets.

## Environment details

The original delivery populated a local feed from NuGet's official HTTPS package endpoint through Python's TLS implementation because the Windows TLS stack could not establish the ordinary NuGet connection in this execution environment. This refactor restored the same pinned dependencies from that existing local feed. The delivered `NuGet.Config` retains the standard nuget.org source for normal use.

NuGet vulnerability auditing was disabled **for this offline/local-feed restore invocation**; no such disabling setting is committed to the delivered project. Perform the normal dependency advisory check in your CI environment. The source ZIP does not include the SDK, NuGet cache, compiled binaries, test databases, generated Data Protection keys or local credentials.

## Not established by these tests

No live connection was made to FS, LOS/LMS, Newgen ECM, apig, OTP, Absher, Nafath, or a production identity provider. Provider assurance, real malware detection, business-rule approval, actual cloud topology, capacity, disaster recovery, retention deletion and OKE deployment have not been validated. The development PDF/identity fixtures are deliberately synthetic. See the mapping and adapter documents before integration.
