namespace ALJUF.Paperless;
public sealed record ReviewedTempUrlResource(string UrlId,string PublicUrl,UrlKind Kind,
    DateTimeOffset CreatedAt,DateTimeOffset UpdatedAt,DateTimeOffset ExpiresAt,long Version);
