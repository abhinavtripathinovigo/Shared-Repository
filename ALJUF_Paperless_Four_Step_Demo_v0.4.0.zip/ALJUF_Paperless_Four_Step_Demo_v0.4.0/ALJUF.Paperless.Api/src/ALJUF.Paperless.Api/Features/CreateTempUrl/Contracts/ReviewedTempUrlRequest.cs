namespace ALJUF.Paperless;
public sealed record ReviewedTempUrlRequest(string UrlId, int? ExpireAfterMinutes = null);
