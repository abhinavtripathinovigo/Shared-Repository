namespace ALJUF.Paperless;
public sealed record ReviewedUpdateUrlRequest(string UrlId, UrlMode? Mode = null, ReviewedTarget? Target = null,
    UrlStatus? Status = null, string? DocumentRevision = null, string? ReasonCode = null);
