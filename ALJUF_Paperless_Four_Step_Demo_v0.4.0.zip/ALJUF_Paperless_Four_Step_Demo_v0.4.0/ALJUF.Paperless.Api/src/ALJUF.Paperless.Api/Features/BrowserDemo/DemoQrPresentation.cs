using System.Text.Encodings.Web;
using QRCoder;
namespace ALJUF.Paperless;

public static class DemoQrPresentation
{
    public static string Png(string url)
    {
        using var data = QRCodeGenerator.GenerateQrCode(url, QRCodeGenerator.ECCLevel.M);
        using var qr = new PngByteQRCode(data);
        return Convert.ToBase64String(qr.GetGraphic(8));
    }
    public static string Access(string html, string url, int maxBytes)
    {
        var png = Png(url);
        var panel = $"""
            <section id="stamp-stage" hidden data-url="{HtmlEncoder.Default.Encode(url)}" data-qr="{png}" data-max="{maxBytes}">
            <h2>Step 4 · Stamp your document</h2><p>Authentication is complete. Add the previewed QR to a new PDF copy.</p>
            <button id="stamp-after-auth" type="button" disabled>Stamp document</button><p id="stamp-message" role="status" aria-live="polite"></p>
            <div id="stamped-actions" hidden><a id="view-stamped" target="_blank" rel="noopener">Open stamped PDF</a> <a id="save-stamped" download="ALJUF-document-qr.pdf">Download PDF</a></div></section>
            """;
        return html.Replace("<body>", "<body class=\"demo-stamping\">")
            .Replace("Your document</h1>", "Step 3 · Authenticate</h1>")
            .Replace("Continue to verify access to your document.", "Verify your identity to enable QR stamping. Use 0123 for this demo.")
            .Replace("<form id=\"start\">", $"<img class=\"actual-qr\" src=\"data:image/png;base64,{png}\" alt=\"QR preview for your temporary document link\" width=\"180\" height=\"180\"><form id=\"start\">")
            .Replace("</main>", panel + "</main>")
            .Replace("<script src=\"/access.js\"", "<script src=\"/demo-assets/pdf-lib.min.js\"></script><script src=\"/demo-assets/stamp.js\"></script><script src=\"/demo-assets/auth-stamp.js\" defer></script><script src=\"/access.js\"");
    }
}
