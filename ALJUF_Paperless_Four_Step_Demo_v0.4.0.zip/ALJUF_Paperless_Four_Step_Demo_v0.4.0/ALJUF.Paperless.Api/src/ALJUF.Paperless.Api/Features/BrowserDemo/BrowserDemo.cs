using System.Net;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.DataProtection;
using QRCoder;

namespace ALJUF.Paperless;

public static class BrowserDemo
{
    private static bool Local(HttpContext c) => c.Request.IsHttps &&
        c.Request.Host.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase) &&
        c.Connection.RemoteIpAddress is { } ip && IPAddress.IsLoopback(ip.IsIPv4MappedToIPv6 ? ip.MapToIPv4() : ip);

    public static void MapBrowserDemo(this WebApplication app)
    {
        var settings = app.Services.GetRequiredService<Settings>();
        if (!app.Environment.IsDevelopment() || !settings.EnableDevelopmentFixtures ||
            !app.Configuration.GetValue<bool>("Paperless:BrowserDemo")) return;
        var tickets = app.Services.GetRequiredService<IDataProtectionProvider>().CreateProtector("LocalBrowserDemo.QrTicket.v1").ToTimeLimitedDataProtector();
        app.MapGet("/demo", (HttpContext c, IAntiforgery csrf) =>
        {
            if (!Local(c)) return Results.NotFound();
            var tokens = csrf.GetAndStoreTokens(c);
            var token = Json.Token();
            var ticket = tickets.Protect(token, TimeSpan.FromMinutes(4));
            return Results.Content($"""
                <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
                <title>ALJUF | Paperless experience</title><link rel="stylesheet" href="/demo-assets/demo.css"></head><body>
                <header class="topbar"><a class="wordmark" href="/demo" aria-label="ALJUF paperless home">ALJUF<span>FINANCE</span></a><span class="header-divider"></span><span class="product-name">Paperless experience</span><span class="demo-tag"><i></i>Leadership demo</span></header>
                <main class="workspace"><section class="intro"><p class="eyebrow">A simpler document journey</p><h1>From document<br>to digital access.</h1><p class="lead">Turn a PDF into a customer-ready experience.<br class="desktop-break"> Preview the QR, verify access, then stamp and download.</p></section>
                <ol class="journey" aria-label="Document journey"><li class="current"><span>01</span><div><strong>Create URL</strong><small>Prepare the link</small></div></li><li><span>02</span><div><strong>Preview QR</strong><small>Temporary access</small></div></li><li><span>03</span><div><strong>Authenticate</strong><small>Verify identity</small></div></li><li><span>04</span><div><strong>Stamp &amp; download</strong><small>Save if needed</small></div></li></ol>
                <div class="main-grid"><section class="upload-card" aria-labelledby="upload-title"><div class="card-heading"><div><p class="eyebrow">Start here</p><h2 id="upload-title">Prepare your document</h2></div><span class="format-pill">PDF</span></div>
                <p class="card-description">Choose an unsigned test PDF to create a QR-enabled customer copy.</p>
                <form id="stamp" method="post" action="/demo" enctype="multipart/form-data" data-max="{settings.MaxFileBytes}">
                <input type="hidden" name="ticket" value="{HtmlEncoder.Default.Encode(ticket)}">
                <input type="hidden" name="{HtmlEncoder.Default.Encode(tokens.FormFieldName)}" value="{HtmlEncoder.Default.Encode(tokens.RequestToken!)}">
                <label class="file-zone" id="file-zone" for="pdf-file"><span class="upload-icon" aria-hidden="true">↑</span><strong id="file-title">Select a PDF document</strong><span id="file-detail">Browse files on this computer</span><span class="browse-label">Choose file</span><input id="pdf-file" type="file" name="file" required accept="application/pdf,.pdf" aria-describedby="file-help"></label>
                <p id="file-help" class="file-help">Unsigned, unencrypted PDF · Maximum {(settings.MaxFileBytes / 1048576d):0.#} MB</p>
                <button class="primary" id="create-button" disabled>Create URL <span aria-hidden="true">→</span></button><p id="message" class="status-message" role="status" aria-live="polite"></p></form>
                <div class="preserve-note"><span aria-hidden="true">✓</span>Your original file stays unchanged. Stamping is available after authentication.</div><noscript>Enable JavaScript to prepare the document link.</noscript></section>
                <aside class="experience-card"><p class="eyebrow">The customer experience</p><h2>One scan.<br>A clear next step.</h2><div class="document-illustration" aria-hidden="true"><div class="document-top"><span>ALJUF</span><span>DOCUMENT</span></div><div class="document-lines"><i></i><i></i><i></i></div><div class="qr-illustration"><b></b><b></b><b></b><span>QR</span></div><div class="document-caption">Your document, digitally accessible</div></div><ul class="benefits"><li><span>01</span>Create the document URL</li><li><span>02</span>Preview its temporary-link QR</li><li><span>03</span>Authenticate, then stamp and download</li></ul><div class="demo-note"><strong>For this demonstration</strong><p>The link lasts {settings.TemporaryUrlDefaultMinutes} minutes. Use <b>0123</b> for the test customer’s last four ID digits.</p></div></aside></div>
                <footer class="page-footer"><span>ALJUF Finance <span class="footer-dot">·</span> Paperless document access</span><a href="/swagger">Explore the API in Swagger <span aria-hidden="true">↗</span></a></footer><p class="local-note">Local demonstration · Use synthetic documents. Customer links open on this computer.</p></main>
                <script src="/demo-assets/create.js"></script></body></html>
                """, "text/html");
        });
        app.MapPost("/demo", async (HttpContext c, IAntiforgery csrf, UrlCreationWorkflow workflow, ReviewedTempUrlService temporary, TimeProvider clock) =>
        {
            if (!Local(c)) return Results.NotFound();
            if (!c.Request.HasFormContentType) return Results.BadRequest("Choose a PDF using the demo form.");
            await csrf.ValidateRequestAsync(c);
            var form = await c.Request.ReadFormAsync(c.RequestAborted);
            string token;
            try { token = tickets.Unprotect(form["ticket"].ToString()); }
            catch (CryptographicException) { return Results.BadRequest("This demo form has expired or is invalid. Reopen /demo to try again."); }
            var file = form.Files.GetFile("file");
            if (file is null || file.Length < 1 || file.Length > settings.MaxFileBytes)
                return Results.BadRequest("Choose a nonempty test PDF within the configured file size limit.");
            using var stream = file.OpenReadStream();
            var bytes = await FileRules.ReadBounded(stream, settings.MaxFileBytes, c.RequestAborted);
            var request = new CreateUrlRequest(UrlMode.Content, "DEMO_PRIVATE",
                new BusinessReference("LOS", "DEMO", "demo-transaction", Convert.ToHexString(SHA256.HashData(System.Text.Encoding.ASCII.GetBytes(token)))[..32], "r1"),
                "demo-customer", "demo-id4", clock.GetUtcNow().AddMinutes(settings.TemporaryUrlDefaultMinutes + 1), ContentType: "application/pdf",
                FileName: Path.GetFileName(file.FileName), Sha256: Convert.ToHexString(SHA256.HashData(bytes)));
            var reply = await workflow.Create("demo-client", request.BusinessReference.DocumentId, request, bytes, false, c.RequestAborted, token);
            var parentId = reply.Body.GetProperty("urlId").GetString()!;
            var childReply = await temporary.Create("demo-client", request.BusinessReference.DocumentId + "-temporary",
                new ReviewedTempUrlRequest(parentId), c.RequestAborted);
            var child = Json.Decode<ReviewedTempUrlResource>(childReply.Body.GetRawText());
            var path = new Uri(child.PublicUrl).AbsolutePath;
            var png = DemoQrPresentation.Png(child.PublicUrl);
            return Results.Content($"""
                <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ALJUF | Preview your QR</title><link rel="stylesheet" href="/demo-assets/demo.css"></head><body>
                <header class="topbar"><a class="wordmark" href="/demo">ALJUF<span>FINANCE</span></a><span class="product-name">Paperless experience</span><span class="demo-tag">Leadership demo</span></header>
                <main class="success-layout"><section class="success-card"><p class="eyebrow">Step 1 complete · URL created</p><h1>Preview your QR.</h1><p class="lead">Step 2 · This QR opens your temporary document link.<br>The same QR will be stamped after authentication.</p>
                <img class="actual-qr" src="data:image/png;base64,{png}" alt="QR code for the temporary document link" width="240" height="240">
                <p class="qr-url">{HtmlEncoder.Default.Encode(child.PublicUrl)}</p><p class="file-help">Expires at {child.ExpiresAt:HH:mm:ss} UTC. Authentication and stamping must be completed before expiry.</p>
                <a class="primary" href="{HtmlEncoder.Default.Encode(path)}">Step 3 · Authenticate <span aria-hidden="true">→</span></a><p class="file-help">Demo: use 0123 for the last four ID digits. The document has not been stamped yet.</p><a class="secondary-link" href="/demo">Start a new journey</a></section></main></body></html>
                """, "text/html");
        });
    }
}
