namespace ALJUF.Paperless;
public sealed record ReviewedQrRequest(string UrlId, UrlKind? Kind, string Format = "png", int? SizePx = null, string? IconAssetId = null);
