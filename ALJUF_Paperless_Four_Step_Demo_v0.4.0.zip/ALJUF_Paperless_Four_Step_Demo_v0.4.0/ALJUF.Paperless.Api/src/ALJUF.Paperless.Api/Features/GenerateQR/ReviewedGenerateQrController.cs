using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace ALJUF.Paperless;
[ApiController]
public sealed class ReviewedGenerateQrController(GenerateQrService service):PaperlessControllerBase
{
    [HttpPost("/v2/qr-codes")][Authorize(Policy="qr:generate")]
    public async Task<IActionResult> Generate()
    {
        var request=await Bodies.Read<ReviewedQrRequest>(HttpContext);
        var expected=request.Format=="svg"?"image/svg+xml":"image/png";
        var accept=Request.Headers.Accept.ToString();
        if(accept.Length>0&&!accept.Contains("*/*")&&!accept.Contains(expected))
            throw new ApiError(406,"NOT_ACCEPTABLE","The requested format is not accepted.");
        var (bytes,type)=await service.GenerateReviewed(Owner,request,Cancellation);
        return File(bytes,type);
    }
}
