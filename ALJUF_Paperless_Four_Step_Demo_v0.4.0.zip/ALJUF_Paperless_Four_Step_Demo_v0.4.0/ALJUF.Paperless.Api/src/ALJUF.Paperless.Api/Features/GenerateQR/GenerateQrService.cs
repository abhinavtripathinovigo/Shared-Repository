using System.Globalization;
using System.Text;
using QRCoder;
using SkiaSharp;

namespace ALJUF.Paperless;

public sealed class GenerateQrService(IUnitOfWork store, UrlPolicyService urls, Settings settings) : IGenerateQrService
{
    public Task<(byte[] Bytes, string ContentType)> Generate(string owner, QrRequest request, CancellationToken ct)
        => GenerateCore(owner,request,ct,false,null);
    public Task<(byte[] Bytes, string ContentType)> GenerateReviewed(string owner,ReviewedQrRequest request,CancellationToken ct)
    {
        if(request.Kind is null)throw ApiError.Validation("kind");
        return GenerateCore(owner,new QrRequest(request.UrlId,request.Format,request.SizePx??settings.QrDefaultSizePx,request.IconAssetId),ct,true,request.Kind);
    }
    private async Task<(byte[] Bytes, string ContentType)> GenerateCore(string owner,QrRequest request,CancellationToken ct,bool reviewed,UrlKind? kind)
    {
        UrlPolicyService.Text(request.UrlId, "urlId");
        if (request.Format is not ("png" or "svg")) throw ApiError.Validation("format");
        if(reviewed ? request.SizePx<1||request.SizePx>settings.QrMaximumSizePx : request.SizePx is not (256 or 512 or 1024))
            throw ApiError.Validation("sizePx");
        var r = store.Read(tx => urls.Owned(tx, request.UrlId, owner));
        if(reviewed && r.Kind!=kind)throw ApiError.Validation("kind","KIND_MISMATCH");
        if(reviewed && r.Request.Mode==UrlMode.Draft && r.Kind==UrlKind.Regular && urls.Effective(r)==UrlStatus.Inactive)
            await urls.Domain(r.Request,owner,ct);
        else {if(urls.Effective(r)!=UrlStatus.Active)throw ApiError.Conflict();await urls.Gate(r,ct);}
        var required = urls.Purpose(r.Request.PurposeCode).RequiredIcon;
        if (required is not null && request.IconAssetId is not null && required != request.IconAssetId) throw ApiError.Validation("iconAssetId");
        var iconId = required ?? request.IconAssetId;
        byte[]? icon = null;
        if (iconId is not null)
        {
            if (!settings.Icons.TryGetValue(iconId, out var path) || !File.Exists(path)) throw ApiError.Unavailable();
            if (new FileInfo(path).Length > 100_000) throw ApiError.Validation("iconAssetId");
            icon = await File.ReadAllBytesAsync(path, ct);
            if (!icon.AsSpan().StartsWith(new byte[] {137,80,78,71,13,10,26,10})) throw ApiError.Validation("iconAssetId");
            using var decoded = SKBitmap.Decode(icon);
            if (decoded is null || decoded.Width > 1024 || decoded.Height > 1024) throw ApiError.Validation("iconAssetId");
        }
        using var data = QRCodeGenerator.GenerateQrCode(urls.Resource(r).PublicUrl, QRCodeGenerator.ECCLevel.H);
        var matrix = data.ModuleMatrix; // QRCoder includes the quiet zone.
        int n = matrix.Count, scale = request.SizePx / n, offset = (request.SizePx - n * scale) / 2;
        if (scale < 2 && (!reviewed || request.Format=="png"))
            throw new ApiError(422,"QR_SIZE_TOO_SMALL",$"The encoded URL requires sizePx of at least {n*2} for PNG.", "sizePx");
        float iconSize = n * scale * 0.12f, iconStart = (request.SizePx - iconSize) / 2;
        byte[] bytes;
        if (request.Format == "svg")
        {
            float svgScale=reviewed?(float)request.SizePx/n:scale;
            float svgOffset=reviewed?0:offset;
            string Num(float v)=>v.ToString("0.######",CultureInfo.InvariantCulture);
            if(reviewed){iconSize=request.SizePx*0.12f;iconStart=(request.SizePx-iconSize)/2;}
            var svg = new StringBuilder($"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{request.SizePx}\" height=\"{request.SizePx}\" viewBox=\"0 0 {request.SizePx} {request.SizePx}\"><rect width=\"100%\" height=\"100%\" fill=\"white\"/><g fill=\"black\">");
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                if (matrix[y][x]) svg.Append($"<rect x=\"{Num(svgOffset+x*svgScale)}\" y=\"{Num(svgOffset+y*svgScale)}\" width=\"{Num(svgScale)}\" height=\"{Num(svgScale)}\"/>");
            svg.Append("</g>");
            if (icon is not null)
            {
                string F(float value) => value.ToString("0.###", CultureInfo.InvariantCulture);
                svg.Append($"<rect x=\"{F(iconStart-2)}\" y=\"{F(iconStart-2)}\" width=\"{F(iconSize+4)}\" height=\"{F(iconSize+4)}\" fill=\"white\"/><image x=\"{F(iconStart)}\" y=\"{F(iconStart)}\" width=\"{F(iconSize)}\" height=\"{F(iconSize)}\" href=\"data:image/png;base64,{Convert.ToBase64String(icon)}\"/>");
            }
            bytes = Encoding.UTF8.GetBytes(svg.Append("</svg>").ToString());
        }
        else
        {
            using var surface = SKSurface.Create(new SKImageInfo(request.SizePx, request.SizePx));
            var canvas = surface.Canvas; canvas.Clear(SKColors.White);
            using var paint = new SKPaint { Color = SKColors.Black, IsAntialias = false };
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                if (matrix[y][x]) canvas.DrawRect(offset+x*scale, offset+y*scale, scale, scale, paint);
            if (icon is not null)
            {
                paint.Color = SKColors.White; canvas.DrawRect(iconStart-2, iconStart-2, iconSize+4, iconSize+4, paint);
                using var bitmap = SKBitmap.Decode(icon);
                canvas.DrawBitmap(bitmap, new SKRect(iconStart, iconStart, iconStart+iconSize, iconStart+iconSize));
            }
            using var snapshot = surface.Snapshot(); using var encoded = snapshot.Encode(SKEncodedImageFormat.Png, 100); bytes = encoded.ToArray();
        }
        await store.Write(tx => { tx.Audit.Append("QrRendered", r.Id, owner, urls.Now); return Task.FromResult(0); });
        return (bytes, request.Format == "png" ? "image/png" : "image/svg+xml");
    }
}
