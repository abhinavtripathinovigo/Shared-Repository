using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record CreateUrlRequest(UrlMode? Mode, string PurposeCode, BusinessReference BusinessReference,
    string? SubjectRef, string AuthPolicyId, DateTimeOffset? ExpiresAt, string Locale = "en", Target? Target = null,
    string? ContentType = null, string? FileName = null, string? Sha256 = null, SubjectDetails? Subject = null, int? MaxAccessCount = null);
