namespace ALJUF.Paperless;
public sealed class ReviewedCreateUrlService(UrlPolicyService rules,ReviewedUrlPolicy reviewed)
{
    public Task<Reply> Create(string owner,string key,ReviewedCreateUrlRequest request,CancellationToken ct)
        => rules.Mutation(owner,"V2.Create",key,request,async tx=>{
            var normalized=await reviewed.Normalize(request,owner,ct);
            var r=new UrlRecord{Id=Guid.NewGuid().ToString("N"),Owner=owner,PublicToken=Json.Token(),
                Request=normalized,Kind=UrlKind.Regular,Status=request.Mode==UrlMode.Draft?UrlStatus.Inactive:UrlStatus.Active,
                CreatedAt=rules.Now,UpdatedAt=rules.Now,ExpiresAt=normalized.ExpiresAt,AuthenticationType=request.AuthenticationType};
            await reviewed.StoreContent(tx,r,request.Target?.Content,ct);rules.Save(tx,r);
            tx.Audit.Append("Created",r.Id,owner,rules.Now);return reviewed.Reply(r,201);
        });
}
