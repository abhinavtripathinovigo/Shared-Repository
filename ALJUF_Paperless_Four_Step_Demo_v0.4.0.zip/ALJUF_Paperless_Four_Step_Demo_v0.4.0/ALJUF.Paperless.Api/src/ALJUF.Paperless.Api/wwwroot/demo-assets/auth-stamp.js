"use strict";
(() => {
 const panel=document.getElementById('stamp-stage'),button=document.getElementById('stamp-after-auth'),message=document.getElementById('stamp-message');
 let sessionId, blobUrl, busy=false;
 function clear(){if(blobUrl)URL.revokeObjectURL(blobUrl);blobUrl=null;document.getElementById('stamped-actions').hidden=true;}
 window.addEventListener('paperless:session',event=>{
  const authorized=event.detail.state==='Authorized';
  document.getElementById('download').hidden=true;
  panel.hidden=!authorized;button.disabled=!authorized||busy||!!blobUrl;sessionId=authorized?event.detail.sessionId:null;
  if(!authorized)clear();else document.getElementById('message').textContent='Identity verified. You can now stamp your document.';
 });
 button.addEventListener('click',async()=>{
  if(!sessionId||busy)return;
  busy=true;button.disabled=true;panel.setAttribute('aria-busy','true');message.textContent='Retrieving the verified document and adding the QR cover…';
  try{
   const response=await fetch('/public/v1/access-sessions/'+encodeURIComponent(sessionId)+'/resource',{credentials:'same-origin',cache:'no-store',redirect:'error'});
   if(!response.ok)throw Error('Access is unavailable or the link has expired. Start a new journey.');
   if(!(response.headers.get('content-type')||'').includes('application/pdf'))throw Error('The document is not a PDF.');
   const original=await response.arrayBuffer();if(original.byteLength>Number(panel.dataset.max))throw Error('The document exceeds the size limit.');
   const stamped=await stampPdf(original,'data:image/png;base64,'+panel.dataset.qr,panel.dataset.url);
   if(stamped.length>Number(panel.dataset.max))throw Error('The stamped copy exceeds the size limit. Choose a smaller PDF.');
   clear();blobUrl=URL.createObjectURL(new Blob([stamped],{type:'application/pdf'}));
   document.getElementById('view-stamped').href=blobUrl;document.getElementById('save-stamped').href=blobUrl;
   document.getElementById('stamped-actions').hidden=false;button.textContent='Document stamped';message.textContent='Your stamped copy is ready. Open it, or download it if needed.';
  }catch(error){clear();message.textContent=error.message+' Unsigned, unencrypted PDFs are required.';button.disabled=false;}
  finally{busy=false;panel.removeAttribute('aria-busy');}
 });
 window.addEventListener('pagehide',clear);
})();
