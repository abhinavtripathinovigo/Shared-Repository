"use strict";
const form=document.querySelector('#stamp'), picker=form.elements.file, button=form.querySelector('button'), msg=document.querySelector('#message');
button.disabled=true;
picker.addEventListener('change',()=>{
 const file=picker.files[0], valid=!!file && /\.pdf$/i.test(file.name) && file.size>0 && file.size<=Number(form.dataset.max);
 document.querySelector('#file-title').textContent=file?file.name:'Select a PDF document';
 document.querySelector('#file-detail').textContent=file?(file.size/1048576).toFixed(2)+' MB · Select to change':'Browse files on this computer';
 document.querySelector('#file-zone').classList.toggle('selected',valid);button.disabled=!valid;
 msg.textContent=file&&!valid?'Choose a nonempty PDF within the displayed size limit.':'';
});
form.addEventListener('submit',()=>{button.disabled=true;button.textContent='Creating your link…';form.setAttribute('aria-busy','true');});
