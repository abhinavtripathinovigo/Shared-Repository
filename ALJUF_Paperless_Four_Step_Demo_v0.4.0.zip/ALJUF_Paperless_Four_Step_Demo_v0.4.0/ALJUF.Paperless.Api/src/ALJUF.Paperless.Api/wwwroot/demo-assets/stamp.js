/* Local demo only. No remote CDN, file upload or analytics dependency. */
async function stampPdf(input, qr, url) {
    const { PDFDocument, StandardFonts, PDFSignature, rgb } = PDFLib;
    const pdf = await PDFDocument.load(input);
    if (!pdf.getPageCount()) throw new Error("Choose a PDF with at least one page.");
    if (pdf.getForm().getFields().some(field => field instanceof PDFSignature))
        throw new Error("Choose an unsigned PDF. Stamping can invalidate digital signatures.");
    const page = pdf.insertPage(0, [595, 842]);
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const image = await pdf.embedPng(qr);
    page.drawText("ALJUF | Paperless", {x:52, y:744, font:bold, size:27});
    page.drawText("Document access", {x:52, y:703, font, size:18});
    page.drawImage(image, {x:52, y:454, width:208, height:208});
    page.drawText("Scan to open the protected customer page.", {x:52, y:421, font, size:13});
    page.drawText(url, {x:52, y:386, font, size:8, color:rgb(0.12,0.23,0.35)});
    page.drawText("The original document begins on the next page.", {x:52, y:329, font, size:12});
    return pdf.save();
}
if (typeof module !== "undefined") module.exports = stampPdf;
