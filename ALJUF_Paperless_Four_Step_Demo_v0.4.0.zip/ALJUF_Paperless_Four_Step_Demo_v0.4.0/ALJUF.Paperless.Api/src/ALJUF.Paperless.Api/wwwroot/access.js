'use strict';
const $ = id => document.getElementById(id);
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const token = location.pathname.split('/').pop();
let session, locale = 'en', pendingTimer, pendingRequest;
const say = (en, ar) => $('message').textContent = locale === 'ar' ? ar : en;
async function send(path, body, key) {
  const response = await fetch(path, {method:body ? 'POST':'GET',credentials:'same-origin',cache:'no-store',
    headers:body ? {'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Idempotency-Key':key}: {},
    body:body ? JSON.stringify(body):undefined});
  if (!response.ok) { const error=await response.json(); throw new Error(error.code || 'UNAVAILABLE'); }
  return response.json();
}
function display(value) {
  session=value; $('start').hidden=true; $('verify').hidden=value.state!=='ChallengeRequired';
  $('download').hidden=value.state!=='Authorized';
  if(value.state==='Authorized') { $('download').href=`/public/v1/access-sessions/${value.sessionId}/resource`; say('Access verified. You can open your document.','تم التحقق. يمكنك فتح المستند.'); }
  else if(value.state==='ChallengeRequired') {
    $('label').textContent=value.nextAction==='EnterLast4' ? (locale==='ar'?'آخر أربعة أرقام من الهوية':'Last four digits of your ID') : (locale==='ar'?'بيانات التحقق':'Verification information');
    $('evidence').maxLength=value.nextAction==='EnterLast4'?4:32;
    say(`Enter the requested information. Attempts remaining: ${value.remainingAttempts}.`,`أدخل البيانات المطلوبة. المحاولات المتبقية: ${value.remainingAttempts}.`);
  } else if(value.state==='Pending') {
    say('Complete verification in the identity provider app.','أكمل التحقق في تطبيق مزود الهوية.');
    clearTimeout(pendingTimer); pendingTimer=setTimeout(async()=>{try{display(await send(`/public/v1/access-sessions/${value.sessionId}`));}catch{say('Verification is unavailable. Please try later.','التحقق غير متاح. يرجى المحاولة لاحقاً.');}},3000);
  } else say('This verification session is no longer available.','جلسة التحقق لم تعد متاحة.');
  window.dispatchEvent(new CustomEvent("paperless:session", {detail:value}));
}
async function submit(form, path, body) {
  const button=form.querySelector('button');button.disabled=true;
  // A network retry reuses the exact key and payload. New evidence is a new attempt.
  const fingerprint=JSON.stringify(body);
  if(!pendingRequest || pendingRequest.fingerprint!==fingerprint || pendingRequest.path!==path) pendingRequest={path,fingerprint,key:crypto.randomUUID()};
  try {display(await send(path,body,pendingRequest.key));pendingRequest=null;}
  catch {say('Unable to complete the request. Retry, or obtain a new link if it has expired.','تعذر إكمال الطلب. أعد المحاولة أو اطلب رابطاً جديداً إذا انتهت صلاحيته.');}
  finally {button.disabled=false;$('evidence').value='';}
}
$('start').addEventListener('submit',event=>{event.preventDefault();submit($('start'),'/public/v1/access-sessions',{token,locale});});
$('verify').addEventListener('submit',event=>{event.preventDefault();const field=session.nextAction==='EnterLast4'?'idLast4':session.nextAction==='EnterID'?'identityNumber':'otpCode';submit($('verify'),`/public/v1/access-sessions/${session.sessionId}/verify`,{evidence:{[field]:$('evidence').value}});});
$('language').addEventListener('click',()=>{locale=locale==='en'?'ar':'en';document.documentElement.lang=locale;document.documentElement.dir=locale==='ar'?'rtl':'ltr';$('title').textContent=locale==='ar'?'مستندك':'Your document';$('intro').textContent=locale==='ar'?'تابع للتحقق من الوصول إلى المستند.':'Continue to verify access to your document.';$('language').textContent=locale==='ar'?'English':'العربية';$('continue').textContent=locale==='ar'?'متابعة':'Continue';$('submit').textContent=locale==='ar'?'تحقق':'Verify';$('download').textContent=locale==='ar'?'فتح المستند':'Open document';$('note').textContent=locale==='ar'?'يخضع هذا الرابط لمدة الصلاحية وسياسة الوصول.':'This link is subject to its expiry and access policy.';if(session)display(session);});
