namespace ALJUF.Paperless;

public sealed class Settings
{
    public int TemporaryUrlDefaultMinutes { get; set; } = 5;
    public int TemporaryUrlMaximumMinutes { get; set; } = 1440;
    public int QrDefaultSizePx { get; set; } = 50;
    public int QrMaximumSizePx { get; set; } = 2048;
    public string DefaultTargetProfileId { get; set; } = "api-gateway-ecm";
    public string PublicOrigin { get; set; } = "https://localhost:7243";
    public string DataDirectory { get; set; } = "data";
    public bool EnableDevelopmentFixtures { get; set; }
    public string? DevelopmentApiKey { get; set; }
    public string? JwtAuthority { get; set; }
    public string? JwtAudience { get; set; }
    public string? KeyCertificatePath { get; set; }
    public string? KeyCertificatePassword { get; set; }
    public int MaxFileBytes { get; set; } = 5 * 1024 * 1024;
    public int SessionSeconds { get; set; } = 180;
    public int IdempotencyHours { get; set; } = 24;
    public int DependencyTimeoutSeconds { get; set; } = 10;
    public string? AdapterBaseUrl { get; set; }
    public string? AdapterApiKey { get; set; }
    public Dictionary<string, PurposePolicy> Purposes { get; set; } = new();
    public Dictionary<string, string[]> ClientPurposes { get; set; } = new();
    public Dictionary<string, AuthPolicy> Authentication { get; set; } = new();
    public Dictionary<string, BackendProfile> Backends { get; set; } = new();
    public Dictionary<string, string> BaseProfiles { get; set; } = new();
    public string[] RedirectOrigins { get; set; } = [];
    public Dictionary<string, string> Icons { get; set; } = new();
}
