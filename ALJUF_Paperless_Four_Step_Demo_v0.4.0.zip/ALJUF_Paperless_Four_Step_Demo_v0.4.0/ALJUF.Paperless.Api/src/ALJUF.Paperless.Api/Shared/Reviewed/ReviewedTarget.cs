namespace ALJUF.Paperless;
public sealed record ReviewedTarget(string? Url = null, string? BaseProfileId = null, string? BackendProfileId = null, InlineContent? Content = null);
