using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Xunit;

namespace ALJUF.Paperless.Tests;

public class BrowserDemoTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    [Fact] public async Task LocalBrowserCreatesProtectedLinkWithoutApiKey()
    {
        using var app = factory.WithWebHostBuilder(b => b.UseSetting("Paperless:BrowserDemo", "true"));
        using var client = new HttpClient(app.Server.CreateHandler(c => c.Connection.RemoteIpAddress = IPAddress.Loopback))
            { BaseAddress = new Uri("https://localhost") };
        var page = await client.GetAsync("/demo");
        page.EnsureSuccessStatusCode();
        var html = await page.Content.ReadAsStringAsync();
        Assert.DoesNotContain(ApiFactory.Key, html);
        var token = Regex.Match(html, "name=\"__RequestVerificationToken\" value=\"([^\"]+)\"").Groups[1].Value;
        Assert.NotEmpty(token);
        client.DefaultRequestHeaders.Add("Cookie",page.Headers.GetValues("Set-Cookie").First().Split(';')[0]);
        using var form = new MultipartFormDataContent();
        form.Add(new StringContent(token), "__RequestVerificationToken");
        form.Add(new StringContent(Regex.Match(html, "name=\"ticket\" value=\"([^\"]+)\"").Groups[1].Value), "ticket");
        form.Add(new ByteArrayContent(Encoding.ASCII.GetBytes("%PDF-1.4\n% synthetic fixture\n%%EOF")), "file", "sample.pdf");
        var result = await client.PostAsync("/demo", form);
        result.EnsureSuccessStatusCode();
        var link = Regex.Match(await result.Content.ReadAsStringAsync(), "href=\"(/u/[0-9a-fA-F]{64})\"").Groups[1].Value;
        Assert.NotEmpty(link);
        Assert.Contains("https://localhost" + link, html);
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync(link)).StatusCode);
        using var invalid = new MultipartFormDataContent();
        invalid.Add(new StringContent("invalid"), "__RequestVerificationToken");
        Assert.Equal(HttpStatusCode.Forbidden, (await client.PostAsync("/demo", invalid)).StatusCode);
        using var remote = new HttpClient(app.Server.CreateHandler(c => c.Connection.RemoteIpAddress = IPAddress.Parse("192.0.2.1")))
            { BaseAddress = new Uri("https://localhost") };
        Assert.Equal(HttpStatusCode.NotFound, (await remote.GetAsync("/demo")).StatusCode);
    }
}
