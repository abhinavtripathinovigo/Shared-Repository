using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed class HttpIntegrations(Settings settings, IHttpClientFactory factory) : IIntegrations
{
    private async Task<T> Call<T>(string path, object body, CancellationToken ct)
    {
        if (!Uri.TryCreate(settings.AdapterBaseUrl, UriKind.Absolute, out var origin)
            || origin.Scheme != "https" || string.IsNullOrWhiteSpace(settings.AdapterApiKey)) throw ApiError.Unavailable();
        using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(origin, path));
        request.Headers.Add("X-Adapter-Key", settings.AdapterApiKey);
        request.Content = new StringContent(Json.Encode(body), Encoding.UTF8, "application/json");
        try
        {
            using var response = await factory.CreateClient("dependencies").SendAsync(request, ct);
            if (!response.IsSuccessStatusCode) throw ApiError.Unavailable();
            return Json.Decode<T>(await response.Content.ReadAsStringAsync(ct));
        }
        catch (HttpRequestException) { throw ApiError.Unavailable(); }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ApiError(504, "DEPENDENCY_TIMEOUT", "The dependency timed out."); }
    }
    public Task<DomainDecision> ValidateDomain(CreateUrlRequest request, string owner, CancellationToken ct)
        => Call<DomainDecision>("domain/validate", new { callerId = owner, request }, ct);
    public async Task Scan(byte[] bytes, string digest, CancellationToken ct)
    {
        var result = await Call<ScanDecision>("content/scan", new { contentBase64 = Convert.ToBase64String(bytes), sha256 = digest }, ct);
        if (!result.Clean) throw ApiError.Validation("file", "INVALID_CONTENT");
    }
    public Task<AuthenticationDecision> Start(UrlRecord url, AuthPolicy policy, string key, CancellationToken ct)
        => Call<AuthenticationDecision>("authentication/start", new { urlId = url.Id, subjectRef = url.Request.SubjectRef,
            method = policy.Type, provider = policy.Provider, idempotencyKey = key }, ct);
    public Task<AuthenticationDecision> Verify(UrlRecord url, SessionRecord session, Evidence evidence, string key, CancellationToken ct)
        => Call<AuthenticationDecision>("authentication/verify", new { urlId = url.Id, subjectRef = url.Request.SubjectRef,
            method = session.Method, provider = session.Provider, session.ProviderRequestId, evidence, idempotencyKey = key }, ct);
    public Task<RedirectDecision> Redirect(UrlRecord url, string target, DateTimeOffset expiresAt, CancellationToken ct)
        => Call<RedirectDecision>("destinations/grant", new { urlId = url.Id, subjectRef = url.Request.SubjectRef, target, expiresAt }, ct);
}

// Only registered when BOTH environment=Development AND explicit fixture setting are present.
// No mock OTP, AbsherOTP, Nafath or full-ID verification. They remain unavailable.
