using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed record AuthenticationDecision(SessionState State, string? ProviderRequestId = null);
