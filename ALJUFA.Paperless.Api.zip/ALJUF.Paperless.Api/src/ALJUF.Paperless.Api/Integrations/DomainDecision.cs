using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed record DomainDecision(bool Valid, string DocumentRevision, DateTimeOffset? IssuedAt = null);
