using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed class TargetResolver(Settings settings, IHttpClientFactory factory)
{
    public Uri Validate(UrlMode mode, Target? target)
    {
        if (target is null) throw ApiError.Validation("target");
        return mode switch
        {
            UrlMode.RedirectUrl when target.RedirectUrl is not null && target.BackendProfileId is null && target.BaseProfileId is null && target.RelativePath is null
                => Redirect(target.RedirectUrl),
            UrlMode.RewriteUrl when target.BackendProfileId is not null && target.RedirectUrl is null && target.BaseProfileId is null
                => Backend(target.BackendProfileId, target.RelativePath),
            UrlMode.BaseUrl when target.BaseProfileId is not null && target.RedirectUrl is null && target.BackendProfileId is null
                => Base(target.BaseProfileId, target.RelativePath),
            _ => throw ApiError.Validation("target", "INVALID_TARGET")
        };
    }
    public Uri Redirect(string text)
    {
        var uri = Secure(text);
        if (!settings.RedirectOrigins.Any(o => Secure(o).GetLeftPart(UriPartial.Authority) == uri.GetLeftPart(UriPartial.Authority)))
            throw ApiError.Validation("target", "INVALID_TARGET");
        return uri;
    }
    private static Uri Secure(string text)
    {
        if (!Uri.TryCreate(text, UriKind.Absolute, out var u) || u.Scheme != "https" || u.UserInfo.Length > 0 || u.Fragment.Length > 0)
            throw ApiError.Validation("target", "INVALID_TARGET");
        return u;
    }
    private static string PathOnly(string? path)
    {
        if (path is null || !path.StartsWith('/') || path.StartsWith("//", StringComparison.Ordinal)
            || path.Contains("..", StringComparison.Ordinal) || path.Length > 512
            || path.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '/' and not '-' and not '_' and not '.'))
            throw ApiError.Validation("target.relativePath", "INVALID_TARGET");
        return path;
    }
    private Uri Backend(string id, string? path)
    {
        if (!settings.Backends.TryGetValue(id, out var p)) throw ApiError.Validation("target.backendProfileId");
        var relative = PathOnly(path);
        if (!p.PathPrefix.EndsWith('/') || !relative.StartsWith(p.PathPrefix, StringComparison.Ordinal)) throw ApiError.Validation("target.relativePath");
        return new Uri(Secure(p.BaseUri), relative);
    }
    private Uri Base(string id, string? path)
    {
        if (!settings.BaseProfiles.TryGetValue(id, out var value)) throw ApiError.Validation("target.baseProfileId");
        var baseUri = Secure(value.EndsWith('/') ? value : value + "/");
        var result = new Uri(baseUri, PathOnly(path).TrimStart('/'));
        if (!baseUri.IsBaseOf(result)) throw ApiError.Validation("target.relativePath");
        return Redirect(result.AbsoluteUri);
    }
    public async Task<byte[]> Fetch(UrlRecord url, CancellationToken ct)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromSeconds(settings.DependencyTimeoutSeconds));
        var target = url.Request.Target!;
        var uri = Validate(UrlMode.RewriteUrl, target);
        var profile = settings.Backends[target.BackendProfileId!];
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        string Secret(string? key) => key is not null && Environment.GetEnvironmentVariable(key) is { Length: > 0 } value ? value : throw ApiError.Unavailable();
        switch (profile.AuthType)
        {
            case "NoAuth": break;
            case "BasicAuth":
                var user = Secret(profile.UsernameEnvironmentVariable);
                if (user.Contains(':')) throw ApiError.Unavailable();
                request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(user + ":" + Secret(profile.SecretEnvironmentVariable))));
                break;
            case "APIKey":
                if (profile.ApiKeyHeader is not ("X-Api-Key" or "ApiKey")) throw ApiError.Unavailable();
                request.Headers.Add(profile.ApiKeyHeader, Secret(profile.SecretEnvironmentVariable)); break;
            default: throw ApiError.Unavailable();
        }
        try
        {
            using var response = await factory.CreateClient("dependencies").SendAsync(request, HttpCompletionOption.ResponseHeadersRead, deadline.Token);
            if (!response.IsSuccessStatusCode || response.StatusCode != System.Net.HttpStatusCode.OK)
                throw new ApiError(502, "BACKEND_FAILURE", "The document could not be retrieved.");
            if (response.Content.Headers.ContentType?.MediaType != "application/pdf") throw ApiError.Validation("backend.contentType", "INVALID_CONTENT");
            await using var stream = await response.Content.ReadAsStreamAsync(deadline.Token);
            return await FileRules.ReadBounded(stream, settings.MaxFileBytes, deadline.Token);
        }
        catch (HttpRequestException) { throw ApiError.Unavailable(); }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ApiError(504, "DEPENDENCY_TIMEOUT", "The dependency timed out."); }
    }
}
