using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record ContentMetadata(string ContentType, long SizeBytes, string Sha256);
