using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public enum AuthenticationType { NoAuth, OTP, AbsherOTP, Nafath, IDVerify, IDVerify4Digit }
