using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record Target(string? RedirectUrl = null, string? BackendProfileId = null, string? BaseProfileId = null, string? RelativePath = null);
