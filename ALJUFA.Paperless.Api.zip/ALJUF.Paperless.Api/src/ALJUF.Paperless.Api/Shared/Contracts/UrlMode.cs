using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public enum UrlMode { RedirectUrl, RewriteUrl, Content, BaseUrl }
