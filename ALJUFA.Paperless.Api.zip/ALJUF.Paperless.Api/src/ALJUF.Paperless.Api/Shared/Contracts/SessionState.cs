using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public enum SessionState { ChallengeRequired, Pending, Authorized, Denied, Expired }
