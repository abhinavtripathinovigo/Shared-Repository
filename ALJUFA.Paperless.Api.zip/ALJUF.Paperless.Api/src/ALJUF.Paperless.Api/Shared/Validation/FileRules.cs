using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public static class FileRules
{
    public static async Task<byte[]> ReadBounded(Stream stream, int maximum, CancellationToken ct)
    {
        using var output = new MemoryStream(); byte[] buffer = new byte[81920];
        int count;
        while ((count = await stream.ReadAsync(buffer, ct)) > 0)
        {
            if (output.Length + count > maximum) throw new ApiError(413, "PAYLOAD_TOO_LARGE", "The file exceeds the configured limit.");
            await output.WriteAsync(buffer.AsMemory(0, count), ct);
        }
        return output.ToArray();
    }
    public static string Validate(byte[]? bytes, string? contentType, string? name, string? digest, int maximum)
    {
        if (bytes is null || bytes.Length == 0 || bytes.Length > maximum) throw ApiError.Validation("file", "INVALID_CONTENT");
        if (contentType != "application/pdf") throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Only PDF content is configured.");
        if (!bytes.AsSpan().StartsWith("%PDF-"u8) || !Encoding.ASCII.GetString(bytes.AsSpan(Math.Max(0, bytes.Length - 1024))).Contains("%%EOF", StringComparison.Ordinal))
            throw ApiError.Validation("file", "INVALID_CONTENT");
        if (string.IsNullOrWhiteSpace(name) || name.Length > 128 || name.Any(c => char.IsControl(c) || "/\\\";".Contains(c)) || !name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase))
            throw ApiError.Validation("fileName");
        var actual = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes));
        if (digest is null || digest.Length != 64 || !Json.Equal(actual, digest.ToUpperInvariant())) throw ApiError.Validation("sha256", "INVALID_CONTENT");
        return actual.ToLowerInvariant();
    }
}
