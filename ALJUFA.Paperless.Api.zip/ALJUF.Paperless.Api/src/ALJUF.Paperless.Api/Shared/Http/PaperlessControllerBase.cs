using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

public abstract class PaperlessControllerBase : ControllerBase
{
    protected string Owner => User.FindFirst("client_id")?.Value ?? User.FindFirst("azp")?.Value
        ?? throw new ApiError(403, "FORBIDDEN", "A service client identity is required.");
    protected string Key => Request.Headers["Idempotency-Key"].ToString();
    protected CancellationToken Cancellation => HttpContext.RequestAborted;
}
