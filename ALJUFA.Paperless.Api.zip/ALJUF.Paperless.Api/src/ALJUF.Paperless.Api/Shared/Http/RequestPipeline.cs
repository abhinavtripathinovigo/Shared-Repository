using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;
using ALJUF.Paperless;

namespace ALJUF.Paperless;

public static class RequestPipeline
{
    public static void UsePaperless(this WebApplication app)
    {
        app.Use(async (ctx, next) =>
        {
            var candidate = ctx.Request.Headers["X-Correlation-ID"].ToString();
            ctx.TraceIdentifier = candidate.Length is > 0 and <= 64 && candidate.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_') ? candidate : Guid.NewGuid().ToString("N");
            ctx.Response.Headers["X-Correlation-ID"] = ctx.TraceIdentifier;
            ctx.Response.Headers.CacheControl = "no-store";
            ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
            ctx.Response.Headers.XContentTypeOptions = "nosniff";
            ctx.Response.Headers.ContentSecurityPolicy = "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";
            try { await next(); }
            catch (Exception e) when (!ctx.Response.HasStarted)
            {
                var error = e switch
                {
                    ApiError a => a,
                    JsonException => new ApiError(400, "MALFORMED_REQUEST", "The JSON request is invalid."),
                    BadHttpRequestException b => new ApiError(b.StatusCode, "MALFORMED_REQUEST", "The request is invalid."),
                    InvalidDataException => new ApiError(400, "MALFORMED_REQUEST", "The multipart request is invalid."),
                    AntiforgeryValidationException => new ApiError(403, "FORBIDDEN", "The browser request could not be validated."),
                    OperationCanceledException => ApiError.Unavailable(),
                    _ => new ApiError(500, "INTERNAL_ERROR", "The request could not be completed.")
                };
                // Never log exception text: upstream URIs and customer data may be embedded in it.
                app.Logger.LogWarning("Request failed: {Code}; correlation {Correlation}", error.Code, ctx.TraceIdentifier);
                ctx.Response.StatusCode = error.Status;
                await ctx.Response.WriteAsJsonAsync(new { code = error.Code, message = error.Message, correlationId = ctx.TraceIdentifier,
                    errors = error.Field is null ? null : new[] { new { field = error.Field, code = error.Code } } });
            }
        });
        app.UseStatusCodePages(async context =>
        {
            var ctx = context.HttpContext;
            await ctx.Response.WriteAsJsonAsync(new { code = ctx.Response.StatusCode == 401 ? "UNAUTHENTICATED" : ctx.Response.StatusCode == 403 ? "FORBIDDEN" : "NOT_FOUND",
                message = "The request could not be completed.", correlationId = ctx.TraceIdentifier });
        });
        app.UseAuthentication(); app.UseAuthorization(); app.UseRateLimiter();
        app.UseStaticFiles();
    }
}
