using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;
using ALJUF.Paperless;

public sealed class ReplyResult(Reply reply) : IResult, Microsoft.AspNetCore.Mvc.IActionResult
{
    public Task ExecuteResultAsync(Microsoft.AspNetCore.Mvc.ActionContext context) => ExecuteAsync(context.HttpContext);
    public async Task ExecuteAsync(HttpContext c)
    {
        c.Response.StatusCode = reply.Status;
        if (reply.ETag is not null) c.Response.Headers.ETag = reply.ETag;
        if (reply.Location is not null) c.Response.Headers.Location = reply.Location;
        foreach (var cookie in reply.Cookies ?? []) c.Response.Cookies.Append(cookie.Name, cookie.Value,
            new CookieOptions { HttpOnly = true, Secure = true, SameSite = SameSiteMode.Strict, Path = "/", Expires = cookie.ExpiresAt, IsEssential = true });
        if (reply.Status != 204) await c.Response.WriteAsJsonAsync(reply.Body, Json.Options, c.RequestAborted);
    }
}
