using ALJUF.Paperless;

var builder = WebApplication.CreateBuilder(args);
builder.AddPaperless();
var app = builder.Build();
app.UsePaperless();
app.MapControllers();
app.MapBrowserDemo();
app.MapLocalSwagger();
app.Run();

public partial class Program;
