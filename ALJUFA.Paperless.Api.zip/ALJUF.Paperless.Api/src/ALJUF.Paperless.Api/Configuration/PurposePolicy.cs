namespace ALJUF.Paperless;

public sealed class PurposePolicy
{
    public string[] AuthPolicies { get; set; } = [];
    public bool Immutable { get; set; } = true;
    public bool Anonymous { get; set; }
    public bool CustomerBound { get; set; } = true;
    public int? DefaultExpirySeconds { get; set; }
    public int? MaximumExpirySeconds { get; set; }
    public bool ReceiptTenYears { get; set; }
    public string? RequiredIcon { get; set; }
}
