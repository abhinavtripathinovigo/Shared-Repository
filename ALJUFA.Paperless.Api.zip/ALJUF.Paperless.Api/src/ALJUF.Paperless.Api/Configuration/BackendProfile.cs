namespace ALJUF.Paperless;

public sealed class BackendProfile
{
    public string BaseUri { get; set; } = "";
    public string PathPrefix { get; set; } = "/documents/";
    public string AuthType { get; set; } = "NoAuth";
    public string? UsernameEnvironmentVariable { get; set; }
    public string? SecretEnvironmentVariable { get; set; }
    public string ApiKeyHeader { get; set; } = "X-Api-Key";
}
