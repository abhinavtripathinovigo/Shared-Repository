namespace ALJUF.Paperless;

public sealed class AuthPolicy
{
    public AuthenticationType Type { get; set; }
    public int MaxAttempts { get; set; } = 5;
    public string Provider { get; set; } = "";
}
