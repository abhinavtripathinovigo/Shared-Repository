namespace ALJUF.Paperless;

public interface IAuditRepository
{
    void Append(string action, string id, string actor, DateTimeOffset now);
}
