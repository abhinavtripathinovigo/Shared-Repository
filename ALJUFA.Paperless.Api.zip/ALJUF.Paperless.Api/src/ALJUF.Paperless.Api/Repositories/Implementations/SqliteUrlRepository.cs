namespace ALJUF.Paperless;

internal sealed class SqliteUrlRepository(SqliteUnitOfWork.Transaction tx) : IUrlRepository
{
    public UrlRecord? Get(string id) => tx.Get<UrlRecord>("url", id);
    public List<UrlRecord> FindByTokenHash(string hash) => tx.Find<UrlRecord>("url", hash);
    public List<UrlRecord> FindByBinding(string binding) => tx.Find<UrlRecord>("binding", binding);
    public void Save(UrlRecord record)
    {
        tx.Put("url", record.Id, record, Json.Hash(record.PublicToken));
        tx.Put("binding", record.Id, record, record.Binding);
    }
}
