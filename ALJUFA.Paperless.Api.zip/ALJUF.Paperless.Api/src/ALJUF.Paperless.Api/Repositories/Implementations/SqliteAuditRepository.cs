namespace ALJUF.Paperless;

internal sealed class SqliteAuditRepository(SqliteUnitOfWork.Transaction tx) : IAuditRepository
{
    public void Append(string action, string id, string actor, DateTimeOffset now) => tx.Audit(action, id, actor, now);
}
