namespace ALJUF.Paperless;

internal sealed class SqliteAccessSessionRepository(SqliteUnitOfWork.Transaction tx) : IAccessSessionRepository
{
    public SessionRecord? Get(string id) => tx.Get<SessionRecord>("session", id);
    public List<SessionRecord> FindByProviderHash(string hash) => tx.Find<SessionRecord>("session", hash);
    public void Save(SessionRecord record) => tx.Put("session", record.Id, record,
        record.ProviderRequestId is null ? "" : Json.Hash(record.Provider + ":" + record.ProviderRequestId));
}
