using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record StoredIdempotency(string Fingerprint, DateTimeOffset ExpiresAt, Reply Reply);
