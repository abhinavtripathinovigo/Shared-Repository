using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed class SessionRecord
{
    public string Id { get; set; } = "";
    public string UrlId { get; set; } = "";
    public long UrlVersion { get; set; }
    public string FlowHash { get; set; } = "";
    public string? AuthorizedHash { get; set; }
    public string? ProviderRequestId { get; set; }
    public string Provider { get; set; } = "";
    public AuthenticationType Method { get; set; }
    public SessionState State { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public string Locale { get; set; } = "en";
}
