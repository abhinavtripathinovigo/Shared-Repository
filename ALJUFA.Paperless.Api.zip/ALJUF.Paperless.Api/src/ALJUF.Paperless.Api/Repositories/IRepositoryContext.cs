namespace ALJUF.Paperless;

public interface IRepositoryContext
{
    IUrlRepository Urls { get; }
    IAccessSessionRepository Sessions { get; }
    IContentRepository Content { get; }
    IIdempotencyRepository Idempotency { get; }
    IAuditRepository Audit { get; }
}
