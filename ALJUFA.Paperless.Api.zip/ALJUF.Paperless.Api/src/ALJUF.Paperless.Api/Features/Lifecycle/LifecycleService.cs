namespace ALJUF.Paperless;

public sealed class LifecycleService(UrlPolicyService policies) : ILifecycleService
{
    public Task<Reply> Lifecycle(string owner, LifecycleRequest request)
        => policies.Mutation(owner, "lifecycle", request.EventId, request, tx =>
        {
            UrlPolicyService.Text(request.UrlId, "urlId");
            var r = policies.Owned(tx, request.UrlId, owner);
            if (request.EventType is not ("Cancelled" or "Rejected" or "Expired" or "Superseded")) throw ApiError.Validation("eventType");
            if (request.Sequence <= 0) throw ApiError.Validation("sequence");
            if (request.Sequence > r.DomainSequence)
            {
                r.DomainSequence = request.Sequence; r.Status = UrlStatus.Revoked; policies.Bump(tx, r, "DomainRevoked");
            }
            return Task.FromResult(Reply.Of(204, new { }));
        });
}

