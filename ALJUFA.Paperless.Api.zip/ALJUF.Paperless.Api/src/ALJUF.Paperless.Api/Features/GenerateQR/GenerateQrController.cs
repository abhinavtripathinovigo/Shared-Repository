using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class GenerateQrController(IGenerateQrService service) : PaperlessControllerBase
{
    [HttpPost("/v1/qr-codes")]
    [Authorize(Policy = "qr:generate")]
    public async Task<IActionResult> Generate()
    {
        var request = await Bodies.Read<QrRequest>(HttpContext);
        var expected = request.Format == "svg" ? "image/svg+xml" : "image/png";
        var accept = Request.Headers.Accept.ToString();
        if (accept.Length > 0 && !accept.Contains("*/*", StringComparison.Ordinal) && !accept.Contains(expected, StringComparison.Ordinal))
            throw new ApiError(406, "NOT_ACCEPTABLE", "The requested format is not accepted.");
        var (bytes, type) = await service.Generate(Owner, request, Cancellation);
        return File(bytes, type);
    }
}
