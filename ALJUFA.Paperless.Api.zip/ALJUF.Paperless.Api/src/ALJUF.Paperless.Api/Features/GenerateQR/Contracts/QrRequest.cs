using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record QrRequest(string UrlId, string Format = "png", int SizePx = 512, string? IconAssetId = null);
