using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record AccessRequest(string Token, string Locale = "en");
