namespace ALJUF.Paperless;

public interface IPublicAccessService
{
    Task Landing(string token, CancellationToken ct);
    Task<Reply> Start(AccessRequest request, string key, string browserBinding, CancellationToken ct);
    Task<Reply> Verify(string id, string? cookie, string key, VerifyRequest request, CancellationToken ct);
    Task<Reply> Status(string id, string? cookie, CancellationToken ct);
    Task<Reply> Callback(string provider, CallbackRequest request);
    Task<ResourceDownload> Download(string id, string? flow, string? authorized, CancellationToken ct);
}
