using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class UrlMetadataController(IUrlMetadataService service) : PaperlessControllerBase
{
    [HttpGet("/v1/urls/{id}")]
    [Authorize(Policy = "url:read")]
    public IActionResult Get(string id) => new ReplyResult(service.Get(id, Owner));
}
