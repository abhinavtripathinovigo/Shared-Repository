namespace ALJUF.Paperless;

public sealed class UrlMetadataService(IUnitOfWork store, UrlPolicyService policies) : IUrlMetadataService
{
    public Reply Get(string id, string owner) => store.Read(tx => { var r = policies.Owned(tx, id, owner); return Reply.Of(200, policies.Resource(r), UrlPolicyService.ETag(r)); });
}
