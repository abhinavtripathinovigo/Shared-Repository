namespace ALJUF.Paperless;

public interface IUrlMetadataService { Reply Get(string id, string owner); }
