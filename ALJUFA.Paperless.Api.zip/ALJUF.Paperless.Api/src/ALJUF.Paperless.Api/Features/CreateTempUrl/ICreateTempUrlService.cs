namespace ALJUF.Paperless;

public interface ICreateTempUrlService
{
    Task<Reply> Create(string owner, string key, CreateUrlRequest request, byte[]? file, CancellationToken ct);
}
