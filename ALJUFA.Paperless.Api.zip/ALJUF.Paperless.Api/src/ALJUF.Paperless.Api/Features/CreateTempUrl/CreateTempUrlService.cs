namespace ALJUF.Paperless;

public sealed class CreateTempUrlService(UrlCreationWorkflow workflow) : ICreateTempUrlService
{
    public Task<Reply> Create(string owner, string key, CreateUrlRequest request, byte[]? file, CancellationToken ct)
        => workflow.Create(owner, key, request, file, true, ct);
}
