using System.Net;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.DataProtection;
using QRCoder;

namespace ALJUF.Paperless;

public static class BrowserDemo
{
    private static bool Local(HttpContext c) => c.Request.IsHttps &&
        c.Request.Host.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase) &&
        c.Connection.RemoteIpAddress is { } ip && IPAddress.IsLoopback(ip.IsIPv4MappedToIPv6 ? ip.MapToIPv4() : ip);

    public static void MapBrowserDemo(this WebApplication app)
    {
        var settings = app.Services.GetRequiredService<Settings>();
        if (!app.Environment.IsDevelopment() || !settings.EnableDevelopmentFixtures ||
            !app.Configuration.GetValue<bool>("Paperless:BrowserDemo")) return;
        var tickets = app.Services.GetRequiredService<IDataProtectionProvider>().CreateProtector("LocalBrowserDemo.QrTicket.v1").ToTimeLimitedDataProtector();
        app.MapGet("/demo", (HttpContext c, IAntiforgery csrf) =>
        {
            if (!Local(c)) return Results.NotFound();
            var tokens = csrf.GetAndStoreTokens(c);
            var token = Json.Token();
            var ticket = tickets.Protect(token, TimeSpan.FromMinutes(4));
            var url = $"https://{c.Request.Host}/u/{token}";
            using var data = QRCodeGenerator.GenerateQrCode(url, QRCodeGenerator.ECCLevel.M);
            using var qr = new PngByteQRCode(data);
            var png = Convert.ToBase64String(qr.GetGraphic(8));
            return Results.Content($"""
                <!doctype html><html lang="en"><meta charset="utf-8"><title>Paperless demo</title>
                <main><h1>Add a QR code to a PDF</h1><p>Choose an unsigned test PDF. A QR cover page will be added to the customer copy; the original file stays unchanged.</p>
                <p><a href="/swagger">View the API in Swagger</a></p>
                <form id="stamp" method="post" action="/demo" enctype="multipart/form-data" data-url="{HtmlEncoder.Default.Encode(url)}" data-qr="{png}" data-max="{settings.MaxFileBytes}">
                <input type="hidden" name="ticket" value="{HtmlEncoder.Default.Encode(ticket)}">
                <input type="hidden" name="{HtmlEncoder.Default.Encode(tokens.FormFieldName)}" value="{HtmlEncoder.Default.Encode(tokens.RequestToken!)}">
                <label>Test PDF <input type="file" name="file" required accept="application/pdf,.pdf"></label>
                <button disabled>Create QR-stamped PDF</button><p id="message" role="status"></p></form>
                <noscript>Enable JavaScript to stamp a PDF.</noscript></main>
                <script src="/demo-assets/pdf-lib.min.js"></script><script src="/demo-assets/stamp.js"></script></html>
                """, "text/html");
        });
        app.MapPost("/demo", async (HttpContext c, IAntiforgery csrf, UrlCreationWorkflow workflow, TimeProvider clock) =>
        {
            if (!Local(c)) return Results.NotFound();
            if (!c.Request.HasFormContentType) return Results.BadRequest("Choose a PDF using the demo form.");
            await csrf.ValidateRequestAsync(c);
            var form = await c.Request.ReadFormAsync(c.RequestAborted);
            string token;
            try { token = tickets.Unprotect(form["ticket"].ToString()); }
            catch (CryptographicException) { return Results.BadRequest("This demo form has expired or is invalid. Reopen /demo to try again."); }
            var file = form.Files.GetFile("file");
            if (file is null || file.Length < 1 || file.Length > settings.MaxFileBytes)
                return Results.BadRequest("Choose a nonempty test PDF within the configured file size limit.");
            using var stream = file.OpenReadStream();
            var bytes = await FileRules.ReadBounded(stream, settings.MaxFileBytes, c.RequestAborted);
            var request = new CreateUrlRequest(UrlMode.Content, "DEMO_PRIVATE",
                new BusinessReference("LOS", "DEMO", "demo-transaction", Convert.ToHexString(SHA256.HashData(System.Text.Encoding.ASCII.GetBytes(token)))[..32], "r1"),
                "demo-customer", "demo-id4", clock.GetUtcNow().AddMinutes(5), ContentType: "application/pdf",
                FileName: Path.GetFileName(file.FileName), Sha256: Convert.ToHexString(SHA256.HashData(bytes)));
            var reply = await workflow.Create("demo-client", request.BusinessReference.DocumentId, request, bytes, true, c.RequestAborted, token);
            var path = new Uri(reply.Body.GetProperty("publicUrl").GetString()!).AbsolutePath;
            return Results.Content($"""
                <!doctype html><html lang="en"><meta charset="utf-8"><title>Customer link ready</title>
                <main><h1>Customer link ready</h1><p>The link expires in five minutes. Use <strong>0123</strong> to verify the demo customer.</p>
                <p><a href="{HtmlEncoder.Default.Encode(path)}">Open customer page</a></p>
                <a href="/demo">Choose another PDF</a></main></html>
                """, "text/html");
        });
    }
}
