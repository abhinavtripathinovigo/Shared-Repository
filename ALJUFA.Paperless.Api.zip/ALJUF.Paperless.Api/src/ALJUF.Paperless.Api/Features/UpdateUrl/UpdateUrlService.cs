namespace ALJUF.Paperless;

public sealed class UpdateUrlService(UrlPolicyService policies, Settings settings, IIntegrations integrations, TargetResolver targets) : IUpdateUrlService
{
    public Task<Reply> UpdateTarget(string owner, string id, string key, string? etag, TargetUpdate request, CancellationToken ct)
        => policies.Mutation(owner, "UU01:" + id, key, new { request, etag }, async tx =>
        {
            var r = policies.Owned(tx, id, owner); UrlPolicyService.Precondition(r, etag); Mutable(r);
            if (r.Request.Mode == UrlMode.Content) throw ApiError.Conflict("MODE_CONFLICT");
            UrlPolicyService.Text(request.DocumentRevision, "documentRevision");
            targets.Validate(r.Request.Mode!.Value, request.Target);
            var updated = r.Request with { Target = request.Target, BusinessReference = r.Request.BusinessReference with { DocumentRevision = request.DocumentRevision } };
            await policies.Domain(updated, owner, ct); r.Request = updated; policies.Bump(tx, r, "TargetUpdated"); return Reply.Of(200, policies.Resource(r), UrlPolicyService.ETag(r));
        });
    private void Mutable(UrlRecord r)
    {
        if (policies.Effective(r) is UrlStatus.Expired or UrlStatus.Revoked) throw ApiError.Conflict();
        if (policies.Purpose(r.Request.PurposeCode).Immutable) throw ApiError.Conflict("IMMUTABLE_RESOURCE");
    }
    public Task<Reply> UpdateContent(string owner, string id, string key, string? etag, ContentUpdate request, byte[] bytes, CancellationToken ct)
        => policies.Mutation(owner, "UU02:" + id, key, new { request, etag, digest = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes)) }, async tx =>
        {
            var r = policies.Owned(tx, id, owner); UrlPolicyService.Precondition(r, etag); Mutable(r);
            if (r.Request.Mode != UrlMode.Content) throw ApiError.Conflict("MODE_CONFLICT");
            UrlPolicyService.Text(request.DocumentRevision, "documentRevision");
            var sha = FileRules.Validate(bytes, request.ContentType, request.FileName, request.Sha256, settings.MaxFileBytes);
            var updated = r.Request with { BusinessReference = r.Request.BusinessReference with { DocumentRevision = request.DocumentRevision },
                FileName = request.FileName, ContentType = request.ContentType, Sha256 = sha };
            await policies.Domain(updated, owner, ct); await integrations.Scan(bytes, sha, ct);
            r.Request = updated; r.ContentId = Guid.NewGuid().ToString("N"); r.Content = new("application/pdf", bytes.Length, sha);
            tx.Content.Save(r.ContentId, bytes); policies.Bump(tx, r, "ContentUpdated"); return Reply.Of(200, policies.Resource(r), UrlPolicyService.ETag(r));
        });
    public Task<Reply> UpdateStatus(string owner, string id, string key, string? etag, StatusUpdate request, CancellationToken ct)
        => policies.Mutation(owner, "UU03:" + id, key, new { request, etag }, async tx =>
        {
            var r = policies.Owned(tx, id, owner); UrlPolicyService.Precondition(r, etag);
            UrlPolicyService.Text(request.ReasonCode, "reasonCode", 48);
            if (request.ReasonCode.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '_')) throw ApiError.Validation("reasonCode");
            if (request.Status is not (UrlStatus.Active or UrlStatus.Inactive)) throw ApiError.Validation("status");
            if (policies.Effective(r) is UrlStatus.Expired or UrlStatus.Revoked) throw ApiError.Conflict();
            if (request.Status == UrlStatus.Active) await policies.Domain(r.Request, owner, ct);
            if (r.Status != request.Status) { r.Status = request.Status.Value; policies.Bump(tx, r, "StatusUpdated"); }
            return Reply.Of(200, policies.Resource(r), UrlPolicyService.ETag(r));
        });
}
