using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record ContentUpdate(string FileName, string ContentType, string Sha256, string DocumentRevision);
