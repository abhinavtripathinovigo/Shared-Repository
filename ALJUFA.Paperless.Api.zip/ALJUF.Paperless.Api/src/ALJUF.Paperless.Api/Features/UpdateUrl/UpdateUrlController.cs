using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class UpdateUrlController(IUpdateUrlService service, Settings settings) : PaperlessControllerBase
{
    [HttpPatch("/v1/urls/{id}/target")]
    [Authorize(Policy = "url:update")]
    public async Task<IActionResult> UpdateTarget(string id)
        => new ReplyResult(await service.UpdateTarget(Owner, id, Key, Request.Headers.IfMatch,
            await Bodies.Read<TargetUpdate>(HttpContext), Cancellation));

    [HttpPut("/v1/urls/{id}/content")]
    [Authorize(Policy = "url:update")]
    public async Task<IActionResult> UpdateContent(string id)
    {
        var (metadata, bytes) = await Bodies.Multipart<ContentUpdate>(HttpContext, settings.MaxFileBytes);
        return new ReplyResult(await service.UpdateContent(Owner, id, Key, Request.Headers.IfMatch, metadata, bytes, Cancellation));
    }

    [HttpPatch("/v1/urls/{id}/status")]
    [Authorize(Policy = "url:update")]
    public async Task<IActionResult> UpdateStatus(string id)
        => new ReplyResult(await service.UpdateStatus(Owner, id, Key, Request.Headers.IfMatch,
            await Bodies.Read<StatusUpdate>(HttpContext), Cancellation));
}
