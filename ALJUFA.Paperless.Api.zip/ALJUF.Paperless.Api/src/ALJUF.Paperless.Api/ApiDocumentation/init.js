"use strict";
SwaggerUIBundle({url:"./v1/swagger.json", dom_id:"#swagger-ui", validatorUrl:null,
    persistAuthorization:false, queryConfigEnabled:false, deepLinking:true,
    presets:[SwaggerUIBundle.presets.apis], layout:"BaseLayout"});
