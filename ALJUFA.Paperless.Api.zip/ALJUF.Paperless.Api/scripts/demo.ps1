param([Parameter(Mandatory=$true)][string]$PdfPath, [string]$BaseUrl = 'https://localhost:7243')
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:Paperless__DevelopmentApiKey)) { throw 'Set Paperless__DevelopmentApiKey to the key used by the local server.' }
$file = Get-Item -LiteralPath $PdfPath
$digest = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
$metadata = @{
 mode = 'Content'; purposeCode = 'DEMO_PRIVATE'; subjectRef = 'demo-customer'; authPolicyId = 'demo-id4'; locale = 'en'
 businessReference = @{ system='LOS'; entityType='DEMO'; entityId='demo-transaction'; documentId=[Guid]::NewGuid().ToString('N'); documentRevision='r1' }
 expiresAt = [DateTimeOffset]::UtcNow.AddMinutes(5).ToString("yyyy-MM-dd'T'HH:mm:ss'Z'")
 contentType = 'application/pdf'; fileName = $file.Name; sha256 = $digest
} | ConvertTo-Json -Depth 5
$headers = @{ 'X-Development-Api-Key'=$env:Paperless__DevelopmentApiKey; 'Idempotency-Key'=[Guid]::NewGuid().ToString('N') }
$result = Invoke-RestMethod -Method Post -Uri "$BaseUrl/v1/temp-urls" -Headers $headers -Form @{ metadata=$metadata; file=$file }
$qrBody = @{ urlId=$result.urlId; format='png'; sizePx=512 } | ConvertTo-Json
Invoke-WebRequest -Method Post -Uri "$BaseUrl/v1/qr-codes" -Headers $headers -ContentType 'application/json' -Body $qrBody -OutFile 'demo-qr.png'
Write-Output "Public URL: $($result.publicUrl)"
Write-Output "Expires: $($result.expiresAt)"
Write-Output 'Synthetic customer verification: 0123. QR saved as demo-qr.png.'
