# Verification record

Date: 27 October 2026. Delivery: v0.2 controller/service/repository refactor. Platform: Windows x64. SDK: workspace-local .NET 10.0.403, downloaded from Microsoft's distribution and checked against its published SHA-512 hash.

## Completed

- Release compilation succeeded with zero compiler warnings and zero errors.
- **26 automated tests passed; zero failed; zero skipped.** Final test execution reported approximately 13 seconds, excluding build/startup time.
- Covered idempotency and concurrent creation, caller ownership, missing/stale ETags, fixed-expiry boundaries, renewal after expiry, target-path rejection, BaseUrl composition, target variants, invalid/immutable content updates, authentication policy enforcement, private session/evidence/cookie checks, concurrent attempt limits, durable store reopening, protected persisted payloads, revocation and QR rendering.
- QR PNGs with and without a registered icon were decoded using ZXing; both decoded to the exact original public URL. SVG output was checked for embedded approved image content and absence of script markup.
- HTTP tests covered anonymous management denial, unknown JSON field rejection, callback authorization, and a complete public Content journey including CSRF validation and exact returned PDF bytes.
- An additional HTTP test exercised the new temporary-creation, metadata, target/status update, QR and lifecycle controllers in one journey, checking expiry, ETags, PNG response and denied public access after revocation.
- Browser JavaScript syntax and PowerShell demonstration-script syntax checks passed.
- Release publish succeeded; the published output contains the access HTML page and browser JavaScript assets.

## Environment details

The original delivery populated a local feed from NuGet's official HTTPS package endpoint through Python's TLS implementation because the Windows TLS stack could not establish the ordinary NuGet connection in this execution environment. This refactor restored the same pinned dependencies from that existing local feed. The delivered `NuGet.Config` retains the standard nuget.org source for normal use.

NuGet vulnerability auditing was disabled **for this offline/local-feed restore invocation**; no such disabling setting is committed to the delivered project. Perform the normal dependency advisory check in your CI environment. The source ZIP does not include the SDK, NuGet cache, compiled binaries, test databases, generated Data Protection keys or local credentials.

## Not established by these tests

No live connection was made to FS, LOS/LMS, Newgen ECM, apig, OTP, Absher, Nafath, or a production identity provider. Provider assurance, real malware detection, business-rule approval, actual cloud topology, capacity, disaster recovery, retention deletion and OKE deployment have not been validated. The development PDF/identity fixtures are deliberately synthetic. See the mapping and adapter documents before integration.
